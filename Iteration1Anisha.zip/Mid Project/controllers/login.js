var express 	= require('express');
var router 		= express.Router();
var loginModel	= require.main.require('./models/login-model');
var customerModel= require.main.require('./models/customer-model');

router.get('/', function(req, res){
	console.log('login page requested!');
	res.render('login/index');
});



router.post('/', function(req, res){
		
		var user ={
			user_email: req.body.user_email,
			user_password: req.body.user_password
		};

		console.log(user);

		loginModel.validate(user, function(status){
			if(status){
				loginModel.getType(user, function(result){
					console.log(result);
					var type = JSON.stringify(result.user_type.toString());
					var status = JSON.stringify(result.account_status.toString());

					if(type=='"customer"' && status=='"active"'){
                        req.session.email = req.body.user_email;						
						res.redirect("/customer");
					}		


					else{
						res.send('CUSTOMER');
					}
				});
				
			}else{
				
			}
		});
});
//Registration
/*router.get('/Employee',function(req,res){		

	var results;

	employeeModel.getAllEmployee(function(results){
			if(results.length > 0){
				console.log(results);
				res.render('admin/adminHome/employees', {employeeList: results});
			}else{
				res.render('admin/adminHome/employees', {employeeList: results});
			}
		});	
	});*/


router.get('/registration',function(req,res){		
	res.render('login/registration');		
	});

router.post('/registration',function(req,res){		
	var customer =
	{		
		customer_fullname: req.body.full_name,
		customer_password: req.body.password,
		customer_email: req.body.email,
		customer_contactno : req.body.contactno,
		customer_address : req.body.address
	}
	customerModel.insertCustomer(customer, function(status){
			if(status){
				customerModel.getCustomerId(customer,function(result){
					console.log(result);
					customer.user_id = result.user_id;
					customer.user_type = 'customer';
					customer.user_status = 'active';

					var user= 
					{
						user_id : customer.user_id,
						user_email : customer.customer_email,
						user_password : customer.customer_password,
						user_type : customer.user_type,
						user_status : customer.user_status
					}
					console.log(customer);
					console.log(user);
					loginModel.insertLogin(user,function(status){
						if(status){
							res.redirect('/login');
						}
						else{
							res.send("Failed");
						}

					});

				});











				
			}else{
				res.redirect('/registration'+req.params.id);
			}
		});
	});




module.exports = router;
