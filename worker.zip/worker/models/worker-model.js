var db = require('./db');

module.exports ={
	
	
	getAllworker:function(callback){
		var sql = "select * from login";
		db.getResult(sql, null, function(results){
			if(results.length > 0){
				callback(results);
			}else{
				callback([]);
			}
		});
	},
	insertworker: function(user, callback){
		var sql = "insert into user values(?,?,?,?,?,?,?,?)";
		db.execute(sql, [null, user.name,user.email,user.password,user.phoneno,user.address,user.type,user.profession], function(status){
			if(status){
				callback(true);
			}else{
				callback(false);
			}
		});
	},
	getworkerId:function(user, callback){
		var sql = "select userid from user where email=? and password=?";
		db.getResult(sql, [user.email,user.password], function(results){
			if(results.length > 0){
				callback(results[0]);
			}else{
				callback(null);
			}
		});
	},
}
