var	express		= require('express');
var router		= express.Router();
var loginModel	= require.main.require('./models/login-model');
var workerModel	= require.main.require('./models/worker-model');
var cvmodel = require.main.require('./models/cv-model');

//Login
router.get('/',function(req,res){
	var user ={
		email : req.session.email,
	};		
	res.render('admin/adminHome/index',{admin : user});
	
});
//view own profile
router.get('/viewprofile', function(req, res){
	
		cvmodel.getAll(function(results){
			if(results.length > 0){
				res.render('admin/adminHome/viewprofile', {cvlist: results});
			}else{
				res.redirect('/admin');
			}
		});
});

//update info

router.get('/edit/:id', function(req, res){
	placemodel.getById(req.params.id, function(result){
		res.render('adminhome/edit', {cv: result});
	});
});

router.post('/updateplace/:id', function(req, res){
	
		var placeinfo = {
		id       : req.params.id,
		place		: req.body.place,
		city		: req.body.city,
		cost	: req.body.cost,
		genre	: req.body.genre,
		description		: req.body.description,
		};

		placemodel.update(placeinfo, function(status){
			if(status){
				res.redirect('/adminhome/information');
			}else{
				res.redirect('/adminhome/updateplace/'+req.params.id);
			}
		});
});

//cv
router.get('/cv?',function(req,res){		
	res.render('worker/workerhome/cv');		
	});

router.post('/cv?',function(req,res){		
	var cv =
	{		
		name: req.body.name,
		email: req.body.email,
		address: req.body.address,
		phoneno: req.body.phoneno,
		eduback: req.body.eduback,
		profession: req.body.profession,
		gender: req.body.gender,
		skill: req.body.skill,
		experience: req.body.experience,
		
		
	}
	console.log(cv);
	cvmodel.insertcv(cv, function(status){
			if(status){
		
			res.redirect('/worker');

				}else{
			res.redirect('/worker/cv');				
		}
		});
});



module.exports = router;
