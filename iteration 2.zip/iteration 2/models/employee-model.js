var db = require('./db');

module.exports ={
	
	
	getAllEmployee:function(callback){
		var sql = "select * from employee";
		db.getResult(sql, null, function(results){
			if(results.length > 0){
				callback(results);
			}else{
				callback([]);
			}
		});
	},
	insertEmployee: function(employee, callback){
		var sql = "insert into employee values(?,?,?,?,?)";
		db.execute(sql, [null, employee.employee_fullname,employee.employee_email, employee.employee_password,employee.employee_contactno], function(status){
			if(status){
				callback(true);
			}else{
				callback(false);
			}
		});
	},
	getEmployeeId:function(employee, callback){
		var sql = "select user_id from employee where user_email=? and user_password=?";
		db.getResult(sql, [employee.employee_email, employee.employee_password], function(results){
			if(results.length > 0){
				callback(results[0]);
			}else{
				callback(null);
			}
		});
	},
	getByEmail:function(employee, callback){
		var sql = "select * from employee where user_email=? ";
		var sqlPrint = "select * from employee where user_email="+employee.email+" ";
		console.log(sqlPrint);
		db.getResult(sql, [employee.email], function(results){
			if(results.length > 0){
				callback(results[0]);
			}else{
				callback(null);
			}
		});
	},
	editEmployee: function(employee, callback){
		var sql = "UPDATE employee SET user_name=?,user_phoneno=? WHERE user_email=?";
		var sqlPrint = "UPDATE employee SET user_name="+employee.employee_fullname+",user_phoneno="+employee.employee_contactno+" WHERE user_email="+employee.employee_email+";";
		console.log(sqlPrint);

		db.execute(sql, [null, employee.employee_fullname ,employee.employee_contactno,employee.employee_email], function(status){
			if(status){
				console.log(status);

				callback(true);
			}else{
				callback(false);
			}
		});
	},
	updateEmployee: function(employee, callback){
		var sql = "update employee set user_name=?, user_phoneno=? where user_email=?";
		db.execute(sql, [employee.employee_fullname , employee.employee_contactno,employee.employee_email], function(status){
			console.log("SQL RUNNING UPDATE employee");
			if(status){
				callback(true);
			}else{
				callback(false);
			}
		});
	}
}
