var	express			= require('express');
var router			= express.Router();
var loginModel		= require.main.require('./models/login-model');
var employeeModel	= require.main.require('./models/employee-model');
var forumModel		= require.main.require('./models/forum-model');


router.get('*', function(req, res, next){
	if(req.session.email == null){
		res.redirect('/logout');
	}else{
		next();
	}
});
router.get('/',function(req,res){
	console.log("Requested : Management " +  req.session.email);
	var user ={
		email : req.session.email,
	};		
	res.render('management/managementHome/index',{management : user});	
});


router.get('/ownProfile',function(req,res){	
	var email = req.session.email;
	var user ={
		email : req.session.email,
	};			
	console.log("Email"+user.email);
	console.log("Email ::"+email);
	employeeModel.getByEmail(user,function(result){
		console.log(result);
		res.render('management/managementHome/ownProfile',{user : result});
	});
});
router.get('/editProfile',function(req,res){	
	var email = req.session.email;
	var user ={
		email : req.session.email,
	};			
	console.log("Email"+user.email);
	console.log("Email ::"+email);
	employeeModel.getByEmail(user,function(result){
		console.log(result);
		res.render('management/managementHome/editProfile',{user : result});
	});
});
router.post('/editProfile',function(req,res){	
	var employee =
	{		
		employee_fullname: req.body.employee_fullname,	
		employee_email: req.body.employee_email,
		employee_contactno : req.body.employee_contactno
		
	}
	console.log(employee);
	employeeModel.updateEmployee(employee, function(status){
		if(status){
			console.log(status);
			res.redirect('/management');
		}

	});	
});
router.get('/forum',function(req,res){
	console.log("Requested : Management " +  req.session.email);
	var user ={
		email : req.session.email,
	};	
	forumModel.getAllForum(function(results){
			if(results.length > 0){
				console.log(results);
				console.log("Rendering");
				res.render('management/managementHome/forum', {forumList: results});	
			}else{
				res.render('management/managementHome/forum',{forumList:results});	
			}
		});	



	res.render('management/managementHome/forum',{management : user});		
});
router.post('/forum',function(req,res){
	console.log("Requested : Management " +  req.session.email);
	var forum ={
		email : req.session.email,
		title : req.body.title,
		article: req.body.article
	};		
	console.log(forum);
	forumModel.insertForum(forum,function(status){
		if(status){
			res.send("Successful");
		}
		res.send("Failed");
	});
});






module.exports = router;