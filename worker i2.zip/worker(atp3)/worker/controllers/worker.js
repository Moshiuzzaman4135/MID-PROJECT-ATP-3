var	express		= require('express');
var router		= express.Router();
var loginModel	= require.main.require('./models/login-model');
var workerModel	= require.main.require('./models/worker-model');
var cvmodel = require.main.require('./models/cv-model');

//Login
router.get('/',function(req,res){
	var user ={
		email : req.session.email,
	};		
	res.render('worker/workerhome/index'/*,{admin : user}*/);
	
});

//view own profile
router.get('/viewprofile', function(req, res){
	
		cvmodel.getAll(function(results){
			if(results.length > 0){
				res.render('worker/workerhome/viewprofile', {cvlist: results});
			}else{
				res.redirect('/worker');
			}
		});
});

//update info

router.get('/edit/:id', function(req, res){
	cvmodel.getById(req.params.id, function(result){
		res.render('worker/workerhome/edit', {cv: result});
	});
});

router.post('/edit/:id', function(req, res){
	
		var cv = {
		id       : req.params.id,
		name: req.body.name,
		email: req.body.email,
		address: req.body.address,
		phoneno: req.body.phoneno,
		eduback: req.body.eduback,
		profession: req.body.profession,
		gender: req.body.gender,
		skill: req.body.skill,
		experience: req.body.experience,
		};

		cvmodel.update(cv, function(status){
			if(status){
				res.redirect('/worker/viewprofile');
			}else{
				res.redirect('/worker/edit/'+req.params.id);
			}
		});
});

//cv
router.get('/cv?',function(req,res){		
	res.render('worker/workerhome/cv');		
	});

router.post('/cv?',function(req,res){		
	var cv =
	{		
		name: req.body.name,
		email: req.body.email,
		address: req.body.address,
		phoneno: req.body.phoneno,
		eduback: req.body.eduback,
		profession: req.body.profession,
		gender: req.body.gender,
		skill: req.body.skill,
		experience: req.body.experience,
		
		
	}
	console.log(cv);
	cvmodel.insertcv(cv, function(status){
			if(status){
		
			res.redirect('/worker');

				}else{
			res.redirect('/worker/cv');				
		}
		});
});



module.exports = router;
