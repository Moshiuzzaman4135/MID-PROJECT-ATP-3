var db = require('./db');

module.exports ={
	
	
	insertcv: function(cv, callback){
		var sql = "insert into cv values(?,?,?,?,?,?,?,?,?,?)";
		db.execute(sql, [null,cv.name,cv.email,cv.address,cv.phoneno,cv.eduback,cv.profession,cv.gender,cv.skill,cv.experience], function(status){
			if(status){
				callback(true);
			}else{
				callback(false);
			}
		});
	},
	update: function(cv, callback){
		var sql = "update cv set name=?,email=?,address=?,phoneno=?,eduback=?,profession=?,gender=?,skill=?,experience=? where id=?";
		db.execute(sql, [cv.name,cv.email,cv.address,cv.phoneno,cv.eduback,cv.profession,cv.gender,cv.skill,cv.experience,cv.id], function(status){
			if(status){
				callback(true);
			}else{
				callback(false);
			}
		});
	},
	getById : function(id, callback){
		var sql = "select * from cv where id=?";
		db.getResult(sql, [id], function(results){
			if(results.length > 0){
				callback(results[0]);
			}else{
				callback(null);
			}
		});
	},
	
	getAll : function(callback){
		var sql = "select * from cv ";
		db.getResult(sql, null, function(results){
			if(results.length > 0){
				callback(results);
			}else{
				callback([]);
			}
		});
	},
	getworkerId:function(user, callback){
		var sql = "select userid from user where email=? and password=?";
		db.getResult(sql, [user.email,user.password], function(results){
			if(results.length > 0){
				callback(results[0]);
			}else{
				callback(null);
			}
		});
	},
}