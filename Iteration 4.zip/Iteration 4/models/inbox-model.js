var db = require('./db');

module.exports ={

	getInboxByEmail : function(email, callback){
		var sql = "select DISTINCT sent_by as user FROM inbox UNION SELECT DISTINCT sent_to as user from inbox WHERE sent_by=? or sent_to=?";
		//var sqlPrint = "select DISTINCT * from inbox sent_by="+email+" or sent_to="+email;
		//console.log(sqlPrint);
		db.getResult(sql,[email,email], function(results){
			if(results.length > 0){
				callback(results);
			}else{
				callback([]);
			}
		});
	},
	loadMessege: function(load, callback){
		var sql = "select * FROM inbox WHERE (sent_by=? AND sent_to=?) or (sent_by=? AND sent_to=?) ORDER BY id DESC";		

		db.getResult(sql,[load.user,load.other,load.other,load.user], function(results){
			console.log(results);
			if(results.length > 0){
				callback(results);
			}else{
				callback([]);
			}
		});
	},
	insertMessege: function(messege, callback){
		console.log(messege);
		var sql = "INSERT INTO `inbox` VALUES (?,?,?,?)";	
		var sqlPrint = "INSERT INTO `inbox` VALUES (null,"+messege.sent_by+","+messege.sent_to+","+messege.messege+");";	
		console.log(sqlPrint);

		db.execute(sql,[null,messege.sent_by,messege.sent_to,messege.messege], function(status){
			console.log(status);
			if(status){
				callback(true);
			}else{
				callback(false);
			}
		});
	},
}