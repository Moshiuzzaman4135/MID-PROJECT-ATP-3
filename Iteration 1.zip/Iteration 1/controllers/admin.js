var	express		= require('express');
var router		= express.Router();
var loginModel	= require.main.require('./models/login-model');
var employeeModel	= require.main.require('./models/employee-model');


//Login
router.get('/',function(req,res){
	console.log("Requested : ADMIN " +  req.session.email);

	var user ={
		email : req.session.email,
	};		
	res.render('admin/adminHome/index',{admin : user});
	
});


router.get('/Employee',function(req,res){		

	var results;

	employeeModel.getAllEmployee(function(results){
			if(results.length > 0){
				console.log(results);
				res.render('admin/adminHome/employees', {employeeList: results});
			}else{
				res.render('admin/adminHome/employees', {employeeList: results});
			}
		});	
	});


router.get('/addEmployee?',function(req,res){		
	res.render('admin/adminHome/addEmployee');		
	});

router.post('/addEmployee?',function(req,res){		
	var employee =
	{		
		employee_fullname: req.body.full_name,
		employee_password: req.body.password,
		employee_email: req.body.email,
		employee_contactno : req.body.contactno
		
	}
	employeeModel.insertEmployee(employee, function(status){
			if(status){
				employeeModel.getEmployeeId(employee,function(result){
					console.log(result);
					employee.user_id = result.user_id;
					employee.user_type = 'manager';
					employee.user_status = 'active';

					var user= 
					{
						user_id : employee.user_id,
						user_email : employee.employee_email,
						user_password : employee.employee_password,
						user_type : employee.user_type,
						user_status : employee.user_status
					}
					console.log(employee);
					console.log(user);
					loginModel.insertLogin(user,function(status){
						if(status){
							res.redirect('/admin/Employee');
						}
						else{
							res.send("Failed");
						}

					});

				});











				
			}else{
				res.redirect('/admin/addEmployee'+req.params.id);
			}
		});
	});




module.exports = router;