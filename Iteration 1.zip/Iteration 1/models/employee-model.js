var db = require('./db');

module.exports ={
	
	
	getAllEmployee:function(callback){
		var sql = "select * from employee";
		db.getResult(sql, null, function(results){
			if(results.length > 0){
				callback(results);
			}else{
				callback([]);
			}
		});
	},
	insertEmployee: function(employee, callback){
		var sql = "insert into employee values(?,?,?,?,?)";
		db.execute(sql, [null, employee.employee_fullname,employee.employee_email, employee.employee_password,employee.employee_contactno], function(status){
			if(status){
				callback(true);
			}else{
				callback(false);
			}
		});
	},
	getEmployeeId:function(employee, callback){
		var sql = "select user_id from employee where user_email=? and user_password=?";
		db.getResult(sql, [employee.employee_email, employee.employee_password], function(results){
			if(results.length > 0){
				callback(results[0]);
			}else{
				callback(null);
			}
		});
	},
}
