-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 09, 2020 at 08:50 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `servicepoint`
--

-- --------------------------------------------------------

--
-- Table structure for table `bid`
--

CREATE TABLE `bid` (
  `id` int(128) NOT NULL,
  `job_id` int(128) NOT NULL,
  `bid_by` varchar(50) COLLATE utf32_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_unicode_ci;

--
-- Dumping data for table `bid`
--

INSERT INTO `bid` (`id`, `job_id`, `bid_by`) VALUES
(1, 1, 'req@req.com'),
(2, 1, 'r@r.com'),
(3, 1, 'abc@abc.com');

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE `comment` (
  `id` int(128) NOT NULL,
  `forum_id` int(128) NOT NULL,
  `commented_by` varchar(50) COLLATE utf32_unicode_ci NOT NULL,
  `comment` varchar(50) COLLATE utf32_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_unicode_ci;

--
-- Dumping data for table `comment`
--

INSERT INTO `comment` (`id`, `forum_id`, `commented_by`, `comment`) VALUES
(1, 10, 'shatil4135@gmail.com', '0'),
(2, 10, 'shatil4135@gmail.com', 'Comment 2'),
(3, 11, 'shatil4135@gmail.com', 'Comment on title 2d'),
(4, 10, 'shatil4135@gmail.com', 'Comment 3'),
(5, 10, 'tarin@gmail.com', 'Tarin commented'),
(6, 14, 'tarin@gmail.com', 'Comment By other');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `user_id` int(50) NOT NULL,
  `user_name` varchar(50) COLLATE utf32_unicode_ci NOT NULL,
  `user_email` varchar(50) COLLATE utf32_unicode_ci NOT NULL,
  `user_password` varchar(50) COLLATE utf32_unicode_ci NOT NULL,
  `user_phoneno` varchar(50) COLLATE utf32_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_unicode_ci;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`user_id`, `user_name`, `user_email`, `user_password`, `user_phoneno`) VALUES
(1, 'Demo2', 'demo2@gmail.com', '1111', '01727546726'),
(2, 'Moshiuzzaman Shatil', 'shatil4135@gmail.com', '4135', '01727546725'),
(3, 'Tarin', 'tarin@gmail.com', '1235', '097119209480239');

-- --------------------------------------------------------

--
-- Table structure for table `forum`
--

CREATE TABLE `forum` (
  `id` int(128) NOT NULL,
  `email` varchar(50) COLLATE utf32_unicode_ci NOT NULL,
  `title` varchar(50) COLLATE utf32_unicode_ci NOT NULL,
  `article` varchar(200) COLLATE utf32_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_unicode_ci;

--
-- Dumping data for table `forum`
--

INSERT INTO `forum` (`id`, `email`, `title`, `article`) VALUES
(10, 'shatil4135@gmail.com', 'Title', 'Demo'),
(11, 'shatil4135@gmail.com', 'Title 2D', 'Demo Post'),
(12, 'shatil4135@gmail.com', 'Somthing', 'Somthing Written Here'),
(13, 'shatil4135@gmail.com', 'ABCD', 'XYZ'),
(14, 'shatil4135@gmail.com', 'Demo 2', 'Demo 1234');

-- --------------------------------------------------------

--
-- Table structure for table `inbox`
--

CREATE TABLE `inbox` (
  `id` int(11) NOT NULL,
  `sent_by` varchar(50) COLLATE utf32_unicode_ci NOT NULL,
  `sent_to` varchar(50) COLLATE utf32_unicode_ci NOT NULL,
  `message` varchar(250) COLLATE utf32_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_unicode_ci;

--
-- Dumping data for table `inbox`
--

INSERT INTO `inbox` (`id`, `sent_by`, `sent_to`, `message`) VALUES
(1, 'shatil4135@gmail.com', 'tarin@gmail.com', 'Hello '),
(2, 'demo2@gmail.com', 'shatil4135@gmail.com', 'Test Hello'),
(3, 'demo2@gmail.com', 'shatil4135@gmail.com', 'Test ABCD'),
(4, 'shatil4135@gmail.com', 'tarin@gmail.com', 'Test XYZ'),
(5, 'shatil4135@gmail.com', 'demo2@gmail.com', 'Good For You'),
(6, 'shatil4135@gmail.com', 'demo2@gmail.com', 'Try This'),
(7, 'shatil4135@gmail.com', 'demo2@gmail.com', '123456789'),
(8, 'shatil4135@gmail.com', 'demo2@gmail.com', 'Last try'),
(9, 'shatil4135@gmail.com', 'demo2@gmail.com', 'Messege sent'),
(10, 'shatil4135@gmail.com', 'tarin@gmail.com', 'Tui Gadha'),
(11, 'shatil4135@gmail.com', 'tarin@gmail.com', 'Test msg by tarin'),
(12, 'tarin@gmail.com', 'shatil4135@gmail.com', 'test reply by tarin');

-- --------------------------------------------------------

--
-- Table structure for table `job`
--

CREATE TABLE `job` (
  `job_id` int(128) NOT NULL,
  `job_title` varchar(50) COLLATE utf32_unicode_ci NOT NULL,
  `job_description` varchar(128) COLLATE utf32_unicode_ci NOT NULL,
  `job_catagory` varchar(12) COLLATE utf32_unicode_ci NOT NULL,
  `posted_by` varchar(12) COLLATE utf32_unicode_ci NOT NULL,
  `job_status` varchar(12) COLLATE utf32_unicode_ci NOT NULL,
  `assigned_to` varchar(12) COLLATE utf32_unicode_ci NOT NULL,
  `fee` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_unicode_ci;

--
-- Dumping data for table `job`
--

INSERT INTO `job` (`job_id`, `job_title`, `job_description`, `job_catagory`, `posted_by`, `job_status`, `assigned_to`, `fee`) VALUES
(1, 'Electrician Needed', 'Installment of new things in house', 'elecrtician', 'a@a.com', 'pending', 'r@r.com', 1200),
(3, 'Make Dress', 'Tailor needed emergency', 'tailor', 'b@b.com', 'pending', 'woker1@gmail', 400),
(4, 'Party ', 'Need A chef for party', 'chef', 'r@r.com', 'finished', 'worker2@gmai', 5000);

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(50) NOT NULL,
  `user_id` int(50) NOT NULL,
  `user_email` varchar(50) COLLATE utf32_unicode_ci NOT NULL,
  `user_password` varchar(50) COLLATE utf32_unicode_ci NOT NULL,
  `user_type` varchar(50) COLLATE utf32_unicode_ci NOT NULL,
  `account_status` varchar(50) COLLATE utf32_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_unicode_ci;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `user_id`, `user_email`, `user_password`, `user_type`, `account_status`) VALUES
(2, 1, 'admin@admin.com', '1234', 'admin', 'active'),
(4, 2, 'shatil4135@gmail.com', '4135', 'manager', 'active'),
(5, 3, 'tarin@gmail.com', '1235', 'manager', 'active'),
(6, 4, 'worker@gmail.com', 'worker', 'worker', 'deactive'),
(7, 6, 'worker3@gmail.com', '1234', 'worker', 'deactive');

-- --------------------------------------------------------

--
-- Table structure for table `worker`
--

CREATE TABLE `worker` (
  `userid` int(250) NOT NULL,
  `name` varchar(50) COLLATE utf32_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf32_unicode_ci NOT NULL,
  `password` varchar(50) COLLATE utf32_unicode_ci NOT NULL,
  `phoneno` int(50) NOT NULL,
  `address` varchar(50) COLLATE utf32_unicode_ci NOT NULL,
  `type` varchar(50) COLLATE utf32_unicode_ci NOT NULL,
  `profession` varchar(50) COLLATE utf32_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_unicode_ci;

--
-- Dumping data for table `worker`
--

INSERT INTO `worker` (`userid`, `name`, `email`, `password`, `phoneno`, `address`, `type`, `profession`) VALUES
(4, 'Worker One', 'worker@gmail.com', 'worker', 1911986445, 'Kha 87-3, East Namapara, Khilkhet , Dhaka - 1229', 'worker', 'chef'),
(6, 'Worker three', 'worker3@gmail.com', '1234', 1727546726, 'Kumilla', 'worker', 'chef');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bid`
--
ALTER TABLE `bid`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `user_id` (`user_id`,`user_email`);

--
-- Indexes for table `forum`
--
ALTER TABLE `forum`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inbox`
--
ALTER TABLE `inbox`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `job`
--
ALTER TABLE `job`
  ADD PRIMARY KEY (`job_id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`,`user_password`);

--
-- Indexes for table `worker`
--
ALTER TABLE `worker`
  ADD PRIMARY KEY (`userid`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `userid` (`userid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bid`
--
ALTER TABLE `bid`
  MODIFY `id` int(128) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `comment`
--
ALTER TABLE `comment`
  MODIFY `id` int(128) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `user_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `forum`
--
ALTER TABLE `forum`
  MODIFY `id` int(128) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `inbox`
--
ALTER TABLE `inbox`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `job`
--
ALTER TABLE `job`
  MODIFY `job_id` int(128) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `worker`
--
ALTER TABLE `worker`
  MODIFY `userid` int(250) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
