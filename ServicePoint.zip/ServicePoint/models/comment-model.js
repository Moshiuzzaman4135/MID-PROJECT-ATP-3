var db = require('./db');

module.exports ={
insertComment: function(comment, callback){
		console.log(comment);
		var sql = "insert into comment values(?,?,?,?)";
		var printSql = "insert into comment values(null,'"+comment.forum_id+"','"+comment.comment_by+"','"+comment.comment+"')";
		console.log(printSql);
		db.execute(sql, [null, comment.forum_id, comment.comment_by,comment.comment], function(status){
			if(status){
				callback(true);
			}else{
				callback(false);
			}
		});
	},
	getAllComment:function(callback){
		var sql = "select * from comment";
		db.getResult(sql, null, function(results){
			if(results.length > 0){
				callback(results);
			}else{
				callback([]);
			}
		});
	},










}