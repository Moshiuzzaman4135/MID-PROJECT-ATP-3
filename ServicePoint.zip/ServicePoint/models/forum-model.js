var db = require('./db');
module.exports ={	
	
	insertForum: function(forum, callback){
		var sql = "insert into forum values(?,?,?,?)";
		var sqlPrint = "insert into forum values(null,"+forum.email+","+forum.title+","+forum.article+")";
		console.log(sqlPrint);
		db.execute(sql, [null, forum.email , forum.title ,forum.article] , function(status){
			console.log(status);
			if(status){
				callback(true);
			}else{
				callback(false);
			}
		});
	},
	getAllForum:function(callback){
		var sql = "select * from forum ORDER BY id DESC;";
		db.getResult(sql, null, function(results){
			if(results.length > 0){
				callback(results);
			}else{
				callback([]);
			}
		});
	},
	
}
