var db = require('./db');
module.exports ={	
	getAllJob:function(callback){
		var sql = "select * from job;";
		db.getResult(sql, null, function(results){
			if(results.length > 0){
				callback(results);
			}else{
				callback([]);
			}
		});
	},

	getJobById:function(job_id,callback){
		var sql = "select * from job where job_id=?;";
		db.getResult(sql, job_id, function(results){
			if(results.length > 0){
				callback(results[0]);
			}else{
				callback(null);
			}
		});
	},




	updateJob: function(job, callback){
		var sql = "update job set job_status='pending' , assigned_to=? where job_id=?";
		var print = "update job set job_status=pending , assigned_to="+job.assigned_to+" where job_id="+job.job_id+"";
		console.log(print);
		db.execute(sql, [job.assigned_to , job.job_id], function(status){
			if(status){
				callback(true);
			}else{
				callback(false);
			}
		});
	},

	cancelJob: function(job_id, callback){
		var sql = "update job set job_status=canelled where job_id=?";
		db.execute(sql, job_id , function(status){
			if(status){
				callback(true);
			}else{
				callback(false);
			}
		});
	}
	
}
