var db = require('./db');

module.exports ={	
	
	
	insertworker: function(user, callback){
		var sql = "insert into worker values(?,?,?,?,?,?,?,?)";
		db.execute(sql, [null, user.name,user.email,user.password,user.phoneno,user.address,user.type,user.profession], function(status){
			if(status){
				callback(true);
			}else{
				callback(false);
			}
		});
	},
	getworkerId:function(user, callback){
		var sql = "select userid from worker where email=? and password=?";
		db.getResult(sql, [user.email,user.password], function(results){
			if(results.length > 0){
				callback(results[0]);
			}else{
				callback(null);
			}
		});
	},
	getAllWorker:function(callback){
		var sql = "select * from worker";
		db.getResult(sql, null, function(results){
			if(results.length > 0){
				callback(results);
			}else{
				callback([]);
			}
		});
	},
	searchName:function(name,callback){
		var sql = "select * from worker where name like '%"+name+"%'";
		db.getResult(sql, null, function(results){
			if(results.length > 0){
				callback(results);
			}else{
				callback([]);
			}
		});
	},
	getByEmail:function(email,callback){
		var sql = "select * from worker where email=?";
		db.getResult(sql, email, function(result){
			if(result.length > 0){
				callback(result);
			}else{
				callback(null);
			}
		});
	},
}
