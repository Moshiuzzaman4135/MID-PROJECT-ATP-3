var db = require('./db');
module.exports ={	
	getAllJob:function(callback){
		var sql = "select * from job;";
		db.getResult(sql, null, function(results){
			if(results.length > 0){
				callback(results);
			}else{
				callback([]);
			}
		});
	},
	getBidByJobId:function(job_id,callback){
		var sql = "select * from bid where job_id=?;";
		db.getResult(sql, job_id, function(results){
			if(results.length > 0){
				callback(results);
			}else{
				callback(null);
			}
		});
	},
	
}
