var	express			= require('express');
var router			= express.Router();
var loginModel		= require.main.require('./models/login-model');
var employeeModel	= require.main.require('./models/employee-model');
var forumModel		= require.main.require('./models/forum-model');
var wokrerModel		= require.main.require('./models/worker-model');
var inboxModel 		= require.main.require('./models/inbox-model');	
var commentModel	= require.main.require('./models/comment-model');	
var jobModel		= require.main.require('./models/job-model');	
var bidModel		= require.main.require('./models/bid-model');	

router.get('*', function(req, res, next){
	if(req.session.email == null){
		res.redirect('/logout');
	}else{
		next();
	}
});
router.get('/',function(req,res){
	console.log("Requested : Management " +  req.session.email);
	var user ={
		email : req.session.email,
	};		
	res.render('management/managementHome/index',{management : user});	
});


router.get('/ownProfile',function(req,res){	
	var email = req.session.email;
	var user ={
		email : req.session.email,
	};			
	console.log("Email"+user.email);
	console.log("Email ::"+email);
	employeeModel.getByEmail(user,function(result){
		console.log(result);
		res.render('management/managementHome/ownProfile',{user : result});
	});
});
router.get('/editProfile',function(req,res){	
	var email = req.session.email;
	var user ={
		email : req.session.email,
	};			
	console.log("Email"+user.email);
	console.log("Email ::"+email);
	employeeModel.getByEmail(user,function(result){
		console.log(result);
		res.render('management/managementHome/editProfile',{user : result});
	});
});
router.post('/editProfile',function(req,res){	
	var employee =
	{		
		employee_fullname: req.body.employee_fullname,	
		employee_email: req.body.employee_email,
		employee_contactno : req.body.employee_contactno
		
	}
	console.log(employee);
	employeeModel.updateEmployee(employee, function(status){
		if(status){
			console.log(status);
			res.redirect('/management');
		}

	});	
});
router.get('/forum',function(req,res){
	console.log("Requested : Management " +  req.session.email);
	var user ={
		email : req.session.email,
	};	
	forumModel.getAllForum(function(results){
			if(results.length > 0){
				console.log(results);
				commentModel.getAllComment(function(forumResult){	
				console.log(forumResult);	
				res.render('management/managementHome/forum', {forumList: results,management:user,commentList:forumResult});		


				});
				
			}else{
				res.redirect("/management");
			}
		});				
});

router.post('/comment/:forum_id',function(req,res){
	
	var comment = {
		forum_id 	: req.params.forum_id,
		comment_by 	: req.session.email,
		comment    	: req.body.comment
 	}
 	console.log(comment);
 	commentModel.insertComment(comment,function(status){
 		console.log(status);
 		if(status){
 			res.redirect('../forum');
 		}
 		else{
 			res.send("Failed");
 		}
 	});
});





router.post('/forum',function(req,res){
	console.log("Requested : Management " +  req.session.email);
	var forum ={
		email : req.session.email,
		title : req.body.title,
		article: req.body.article
	};		
	console.log(forum);
	forumModel.insertForum(forum,function(status){
		console.log(status);
		if(status){
			res.redirect('/management');
		}
		else{
			res.redirect('/forum');
		}
	});
});
router.get('/workerlist',function(req,res){	
	wokrerModel.getAllWorker(function(results){
		console.log(results)
		if(results.length>0){
			res.render('management/managementHome/workerList',{workerList : results})
		}
		else{
		res.render('management/managementHome/workerList',{workerList : results})	
	}	
	});	
});


router.get('/searchworker/:key', function(req, res){
	var keyword = req.params.key;
	console.log("searchworker");
	wokrerModel.searchName(keyword,function(results){
			res.render('management/managementHome/searchworker', {workerList: results});
	});
});
router.get('/viewWorker/:email', function(req, res){
	var email = req.params.email;
	wokrerModel.getByEmail(email,function(result){
		console.log(result);
		if(result.length>0){
			loginModel.getByEmail(email,function(loginStatus){
				console.log("status"+loginStatus.account_status);
				res.render('management/managementHome/viewWorker', {worker: result , login : loginStatus});
			});
			
		}
		else{
			res.redirect('management');
		}
	}); 
});

router.get('/active/:email', function(req, res){
	var email = req.params.email;
	loginModel.setActiveById(email,function(status){
		if(status){
			res.redirect("../viewWorker/"+email+"");
		}
		else{
			res.redirect("../viewWorker/"+email+"");
		}
	});
	

});

router.get('/deactive/:email', function(req, res){
	var email = req.params.email;
	loginModel.setDeactiveById(email,function(status){
		if(status){
			res.redirect("../viewWorker/"+email+"");
		}
		else{
			res.redirect("../viewWorker/"+email+"");
		}
	});	
});

router.get('/inbox', function(req, res){
	var email = req.session.email;
	console.log(email);	
	inboxModel.getInboxByEmail(email,function(results){
		res.render('management/managementHome/inbox',{users : results});

	});
});
router.get('/messege/:email', function(req, res){
	var load =
	{
		user : req.session.email,
		other : req.params.email
	}
	console.log(load);	
	inboxModel.loadMessege(load,function(results){
		console.log("Here are -"+results);
		res.render('management/managementHome/messege',{messegeList : results});
		//console.log(results);
	});
});

router.post('/messege/:email', function(req, res){
	var messege =
	{
		sent_by : req.session.email,
		sent_to : req.params.email,
		messege : req.body.messege
	}
	console.log(messege);	
	inboxModel.insertMessege(messege,function(status){
		if(status){
			res.redirect("../messege/"+req.params.email);
		}
		else{
			res.send("Failed");
		}
		
	});
});

router.get('/joblist', function(req, res){	
	jobModel.getAllJob(function(resultsJob){
		res.render('management/managementHome/viewJobs',{ jobList : resultsJob })
	});	
});

router.get('/viewjob/:job_id', function(req, res){	
	var job_id = req.params.job_id;
	jobModel.getJobById(job_id,function(result){
		bidModel.getBidByJobId(job_id,function(bidResults){
			console.log(bidResults);
			res.render('management/managementHome/jobDetails',{ job : result ,bidList : bidResults})
		});
		
	});
});

router.post('/setWorker/:job_id', function(req, res){
	var job =
	{
		job_id 		:req.params.job_id,
		assigned_to 	: req.body.assigned_to
	}
	console.log(job);

	jobModel.updateJob(job,function(status){
		if(status){
			res.redirect("../viewjob/"+job.job_id);
		}
		else{
			res.send("Failed");
		}
	});
});






module.exports = router;