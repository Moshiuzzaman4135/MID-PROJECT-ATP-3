var db = require('./db');

module.exports ={

	validate: function(user, callback){
		var sql = "select * from login where email=? and password=?";
		var sqlPrint = "select * from login where email="+user.email+" and password="+user.password+";";
		console.log(sqlPrint);
		db.getResult(sql, [user.email, user.password], function(result){
			if(result.length > 0){
				callback(true);
			}else{
				callback(false);
			}
		});
	},
	setDeactiveById : function(email, callback){
		var sql = "update login set status='deactive' where email=?  ";
		var sqlPrint = "update login set status='deactive' where email="+email;
		console.log(sqlPrint);
		db.execute(sql,[email], function(status){
			if(status){
				callback(true);
			}else{
				callback(false);
			}
		});
	},
	getType: function(user, callback){
		var sql = "select type,status from login where email=? and password=?";
		var sqlPrint = "select type from login where email="+user.email+" and password="+user.password+";";
		console.log(sqlPrint);
		db.getResult(sql,[user.email, user.password], function(result){
			if(result.length > 0){
				callback(result[0]);
			}else{
				callback(null);
			}
		});
	},
	update: function(login, callback){
		var sql = "update login set userid=?,password=?,type=?,status=? where email=?";
		db.execute(sql, [login.userid,login.email,login.password,login.type,login.status], function(status)
		{
			console.log(status);
			if(status){
				callback(true);
			}else{
				callback(false);
			}
		});
	},
	insertLogin: function(login, callback){
		var sql = "insert into login values(?,?,?,?,?,?)";
		db.execute(sql, [ null,login.userid,login.email,login.password,login.type,login.status ], function(status){
			if(status){
				callback(true);
			}else{
				callback(false);
			}
		});
	},
	
}