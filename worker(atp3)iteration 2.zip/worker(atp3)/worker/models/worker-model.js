var db = require('./db');

module.exports ={
	
	
	getAllworker:function(callback){
		var sql = "select * from login";
		db.getResult(sql, null, function(results){
			if(results.length > 0){
				callback(results);
			}else{
				callback([]);
			}
		});
	},
	update: function(user, callback){
		var sql = "update user set name=?,password=?,phoneno=?,address=?,type=?,profession=? where email=?";
		db.execute(sql, [user.name,user.email,user.password,user.phoneno,user.address,user.type,user.profession,user.id], function(status)
		{
			console.log(status);
			if(status){
				callback(true);
			}else{
				callback(false);
			}
		});
	},
	insertworker: function(user, callback){
		var sql = "insert into user values(?,?,?,?,?,?,?,?)";
		db.execute(sql, [null, user.name,user.email,user.password,user.phoneno,user.address,user.type,user.profession], function(status){
			if(status){
				callback(true);
			}else{
				callback(false);
			}
		});
	},
	getbyemail : function(user,callback)
	{
		var sql="select * from user where email=?";
		var sqlPrint= "select * from user where email="+user.email+"";
		console.log(sqlPrint);
		db.getResult(sql,[user.email],function(results){
			if(results.length > 0){
				callback(results[0]);
			}else{
				callback(null);
			}
		});
	},

	getById : function(id, callback){
		var sql = "select * from user where id=?";
		db.getResult(sql, [id] , function(results){
			if(results.length > 0){
				callback(results[0]);
			}else{
				callback(null);
			}
		});
	},
	
	
	getworkerId:function(user, callback){
		var sql = "select userid from user where email=? and password=?";
		db.getResult(sql, [user.email,user.password], function(results){
			if(results.length > 0){
				callback(results[0]);
			}else{
				callback(null);
			}
		});
	},
}
