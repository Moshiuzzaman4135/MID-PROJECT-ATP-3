var db = require('./db');

module.exports ={

	
getAll : function(callback){
		var sql = "select * from joblist ";
		db.getResult(sql, null, function(results){
			if(results.length > 0){
				callback(results);
			}else{
				callback([]);
			}
		});
	},
	getById : function(customerid, callback){
		var sql = "select * from customer where customerid=?";
		db.getResult(sql, [customerid] , function(results){
			if(results.length > 0){
				callback(results[0]);
			}else{
				callback(null);
			}
		});
	},
	
}