var	express		= require('express');
var router		= express.Router();
var loginModel	= require.main.require('./models/login-model');
var workerModel	= require.main.require('./models/worker-model');
var cvmodel = require.main.require('./models/cv-model');

router.get('/',function(req,res){
	var user ={
		email : req.session.email,
	};		
	res.render('nonactive/index',{admin : user});
	
});


//cv
router.get('/cv?',function(req,res){		
	res.render('nonactive/cv');		
	});

router.post('/cv?',function(req,res){		
	var cv =
	{		
		name: req.body.name,
		email: req.body.email,
		address: req.body.address,
		phoneno: req.body.phoneno,
		eduback: req.body.eduback,
		profession: req.body.profession,
		gender: req.body.gender,
		skill: req.body.skill,
		experience: req.body.experience,
		
		
	}
	console.log(cv);
	cvmodel.insertcv(cv, function(status){
			if(status){
		
			res.redirect('/nonactive');

				}else{
			res.redirect('/nonactive/cv');				
		}
		});
});



module.exports = router;
