var express 	= require('express');
var router 		= express.Router();
var loginModel	= require.main.require('./models/login-model');
var workerModel = require.main.require('./models/worker-model');
router.get('/', function(req, res){
	console.log('login page requested!');
	res.render('login/index');
});
router.post('/', function(req, res){
		
		var user ={
			email: req.body.email,
			password: req.body.password
		};

		//console.log(user.email);

		loginModel.validate(user, function(status){
			if(status){
				loginModel.getType(user, function(result){
					console.log('Here');
					var type = JSON.stringify(result.type.toString());
					var status = JSON.stringify(result.status.toString());
                    console.log(type);
					console.log(status);
					if(type=='"worker"' && status=='"Deactive"'){
						req.session.email = req.body.email;		
						res.redirect('/nonactive');
					}
					else if(type=='"worker"' && status=='"active"'){		
						req.session.email = req.body.email;		
						res.redirect('/worker');
					}


					else{
						res.send('CUSTOMER');
					}
				});
				
			}else{
				
			}
		});
});


//Registration
router.get('/registration?',function(req,res){		
	res.render('login/registration');		
	});

router.post('/registration?',function(req,res){		
	var user =
	{		
		name:        req.body.name,
		email:       req.body.email,
		password:    req.body.password,
		phoneno:     req.body.phoneno,
		address:     req.body.address,
		type:        req.body.type,
		profession:  req.body.profession
		
		
	}
	
	workerModel.insertworker(user, function(status){
			if(status){
				workerModel.getworkerId(user,function(result){
					console.log(result);
					user.userid = result.userid;
					user.status = 'Deactive';

					var login= 
					{
						userid : user.userid,
						email : user.email,
						password : user.password,
						type : user.type,
						status : user.status
					}
					console.log(user);
					console.log(login);
					loginModel.insertLogin(user,function(status){
						if(status){
							res.redirect('/login');
						}
						else{
							res.send("Failed");
						}

					});

				});
}else{
				res.redirect('/login/registration'+req.params.id);
			}
		});
	});


module.exports = router;
