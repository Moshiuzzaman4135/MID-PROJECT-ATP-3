var	express		= require('express');
var router		= express.Router();
var loginModel	= require.main.require('./models/login-model');
var workerModel	= require.main.require('./models/worker-model');
var cvmodel = require.main.require('./models/cv-model');
var jobmodel = require.main.require('./models/job-model');
//Login
router.get('/',function(req,res){
	console.log("Requested : worker " + req.session.email);
	var user ={
		email : req.session.email,
	};		
	console.log(user);
	res.render('worker/workerhome/index',{worker : user});
	
});
//view customer information

router.get('/customerdetails/:customerid', function(req, res){
		var customerid=req.params.customerid;
		
		jobmodel.getById(customerid,function(results){
			
				res.render('worker/workerhome/customerdetails', {customer: results});
			
		});
});



//view own profile
router.get('/viewprofile', function(req, res){
	    var email=req.session.email;
		var cv=
		{
			email : req.session.email,
			
		};
		
		cvmodel.getbyemail(cv,function(results){
			
				res.render('worker/workerhome/viewprofile', {cv: results});
			
		});
});
//view joblist

router.get('/joblist', function(req, res){
	
		jobmodel.getAll(function(results){
			if(results.length > 0){
				res.render('worker/workerhome/joblist', {joblist: results});
			}else{
				res.redirect('/worker');
			}
		});
});



//view own information
router.get('/userinformation', function(req, res){
	    var email=req.session.email;
		var user=
		{
			email : req.session.email,
			
		};
		
		workerModel.getbyemail(user,function(results){
			
				res.render('worker/workerhome/userinformation', {user: results});
			
		});
});

//update information

router.get('/update/:email', function(req, res){
	var user={ email: req.params.email };
	workerModel.getbyemail(user,function(result){
		res.render('worker/workerhome/update', {user: result});
	});
});

router.post('/update/:email',function(req,res){		
	var user =
	{	
		userid	:	req.body.id,
		name:        req.body.name,
		email:       req.body.email,
		password:    req.body.password,
		phoneno:     req.body.phoneno,
		address:     req.body.address,
		type:        req.body.type,
		profession:  req.body.profession
		
		
	}
	console.log(user);
	workerModel.update(user, function(status){
			if(status){
				workerModel.getById(user,function(result){
					console.log(result);
					//user.userid = result.userid;
					user.status = 'active';

					var login= 
					{
						userid : user.userid,
						email : user.email,
						password : user.password,
						type : user.type,
						status : user.status
					}
					console.log(user);
					console.log(login);
					loginModel.update(user,function(status){
						if(status){
							res.send("successfull");
							//res.redirect('worker/userinformation');
						}
						else{
							res.send("Failed");
						}

					});

				});
}else{
				res.redirect('/login/registration'+req.params.id);
			}
		});
	});


//update profile

router.get('/edit/:id', function(req, res){
	cvmodel.getById(req.params.id, function(result){
		res.render('worker/workerhome/edit', {cv: result});
	});
});

router.post('/edit/:id', function(req, res){
	
		var cv = {
		id       : req.params.id,
		name: req.body.name,
		email: req.body.email,
		address: req.body.address,
		phoneno: req.body.phoneno,
		eduback: req.body.eduback,
		profession: req.body.profession,
		gender: req.body.gender,
		skill: req.body.skill,
		experience: req.body.experience,
		};

		cvmodel.update(cv, function(status){
			if(status){
				res.redirect('/worker/viewprofile');
			}else{
				res.redirect('/worker/edit/'+req.params.id);
			}
		});
});






module.exports = router;
