var db = require('./db');

module.exports ={

	/*validate: function(user, callback){
		var sql = "select * from job where user_email=? and user_password=?";
		var sqlPrint = "select * from login where user_email="+user.user_email+" and user_password="+user.user_password+";";
		console.log(sqlPrint);
		db.getResult(sql, [user.user_email, user.user_password], function(result){
			if(result.length > 0){
				callback(true);
			}else{
				callback(false);
			}
		});
	},*/
	/*getType: function(user, callback){
		var sql = "select user_type,account_status from login where user_email=? and user_password=?";
		var sqlPrint = "select user_type from login where user_email="+user.user_email+" and user_password="+user.user_password+";";
		console.log(sqlPrint);
		db.getResult(sql,[user.user_email, user.user_password], function(result){
			if(result.length > 0){
				callback(result[0]);
			}else{
				callback(null);
			}
		});

	},*/
	insertForum: function(forum, callback){
		var sql = "insert into forum values(?,?,?,?)";
		//var sqlPrint="insert into job values user_email="+job.job_email+"status="+job.job_status+"category="+job.job_category+"title="+job.job_title+"description="+job.job_description+";";
		//console.log(sqlPrint);
		db.execute(sql, [ null,forum.forum_email,forum.forum_title,forum.forum_description], function(status){
			if(status){
				callback(true);
			}else{
				callback(false);
			}
		});

	},
	/*getAllJob:function(callback){
		var sql = "select * from job";
		db.getResult(sql, null, function(results){
			if(results.length > 0){
				callback(results);
			}else{
				callback([]);
			}
		});
	},
	getAllJobByEmail:function(job,callback){
		var sql = "select * from job where user_email=?";
		db.getResult(sql, [job.email], function(results){
			if(results.length > 0){
				callback(results);
			}else{
				callback(null);
			}
		});
	},
	getByEmail:function(job, callback){
		var sql = "select * from job where user_email=? ";
		var sqlPrint = "select * from job where user_email="+job.email+" ";
		console.log(sqlPrint);
		db.getResult(sql, [job.email], function(results){
			if(results.length > 0){
				callback(results[0]);
			}else{
				callback(null);
			}
		});
	},*/
	
}