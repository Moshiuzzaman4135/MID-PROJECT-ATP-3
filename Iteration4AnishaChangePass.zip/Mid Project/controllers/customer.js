var	express		= require('express');
var router		= express.Router();
var loginModel	= require.main.require('./models/login-model');
var customerModel	= require.main.require('./models/customer-model');
var jobModel	= require.main.require('./models/job-model');
var forumModel	= require.main.require('./models/forum-model');


//Login
router.get('/',function(req,res){	
	console.log("Requested : Customer " +  req.session.email);
	var user ={
		email : req.session.email,
	};		
	res.render('customer/customerHome/index',{customer : user});
	
});

router.get('/ownInfo',function(req,res){	
	var email = req.session.email;
	var user ={
		email : req.session.email,
	};			
	console.log("Email"+user.user_email);
	console.log("Email ::"+email);
	customerModel.getByEmail(user,function(result){
		console.log(result);
		res.render('customer/customerHome/ownInfo',{user : result});
	});
});
router.get('/editProfile',function(req,res){	
	var email = req.session.email;
	var user ={
		email : req.session.email,
	};			
	console.log("Email"+user.user_email);
	console.log("Email ::"+email);
	customerModel.getByEmail(user,function(result){
		console.log(result);
		res.render('customer/customerHome/editProfile',{user : result});
	});
});
router.post('/editProfile',function(req,res){
console.log("post a jai")	
	var customer=
	{
		customer_fullname:req.body.fullname,
		customer_password:req.body.password,
		customer_address:req.body.address,
		customer_email:req.body.email,
		customer_contactno:req.body.contactno,

	}
	console.log(customer);
	customerModel.update(customer,function(status){
		if(status){
			console.log(status);
			res.render('customer/customerHome/editProfile');
		}
		else{
			res.send(unsuccessfull);
		}
	});
});
router.get('/job',function(req,res){	
	var email = req.session.email;
	var user ={
		email : req.session.email,
	};			
	console.log("Email"+user.user_email);
	console.log("Email ::"+email);
	customerModel.getByEmail(user,function(result){
		console.log(result);
		res.render('job/index',{user : result});
	});
});
router.post('/job',function(req,res){	
	var email = req.session.email;
	var user ={
		email : req.session.email,
	};	
	customerModel.getByEmail(user,function(result){
		console.log(result);
		var job=
	{
		job_email:req.session.email,
		job_status:req.body.status,
		job_category:req.body.category,
		job_title:req.body.title,
		job_description:req.body.description,
		job_fee:req.body.fee,

	}
	console.log(job);
	jobModel.insertJob(job,function(status){
		if(status){
			console.log(status);
			res.render('/customer');
		}
		else{
			res.send("unsuccessfull");
		}
	});
		res.render('customer/customerHome/ownInfo',{user : result});
	});
	
});
router.get('/jobInfo',function(req,res){	
	var email = req.session.email;
	var user ={
		email : req.session.email,
	};
	
	jobModel.getAllJobByEmail(user,function(results){
		if(results.length > 0){
				res.render('job/jobInfo', {userlist: results});
			}else{
				res.redirect('/customerHome/index');
			}
		});
});
router.get('/changePass',function(req,res){	
	var email = req.session.email;
	var user ={
		email : req.session.email,
	};			
	console.log("Email"+user.user_email);
	console.log("Email ::"+email);
	customerModel.getByEmail(user,function(result){
		console.log(result);
		res.render('customer/customerHome/changePass',{user : result});
	});
});
router.post('/changePass',function(req,res){		
	var customer =
	{		
		customer_oldpassword:req.body.oldpassword,
		customer_password: req.body.password,
		customer_email: req.body.email
		
	}
	customerModel.changePass(customer, function(status){
			if(status){
				customerModel.getCustomerId(customer,function(result){
					console.log(result);
					customer.user_id = result.user_id;

					var user= 
					{
						user_id : customer.user_id,
						user_oldpassword:customer.customer_oldpassword,
						user_email : customer.customer_email,
						user_password : customer.customer_password
						
					}
				
					loginModel.changePass(user,function(status){
						if(status){
							res.redirect('/login');
						}
						else{
							console.log("did not match");
							res.redirect("customer/customerHome/changePass");
						}

					});

				});
				
			}else{
				res.redirect('/registration'+req.params.id);
			}
		});
	});

//forum
router.get('/forum',function(req,res){	
	var email = req.session.email;
	var user ={
		email : req.session.email,
	};			
	console.log("Email"+user.user_email);
	console.log("Email ::"+email);
	customerModel.getByEmail(user,function(result){
		console.log(result);
		res.render('customer/customerHome/forum',{user : result});
	});
});
router.post('/forum',function(req,res){	
	var email = req.session.email;
	var user ={
		email : req.session.email,
	};	
	customerModel.getByEmail(user,function(result){
		
		var forum=
	{
		forum_email:req.session.email,
		forum_title:req.body.title,
		forum_description:req.body.description
		

	}
	console.log(forum);
	forumModel.insertForum(forum,function(status){
		if(status){
			console.log(status);
			res.render('/customer');
		}
		else{
			res.send("unsuccessfull");
		}
	});
		res.render('customer/customerHome/ownInfo',{user : result});
	});
	
});








module.exports = router;

