var express 		= require('express');
var bodyParser 		= require('body-parser');
var ejs 			= require('ejs');
var exSession 		= require('express-session');
var cookieParser 	= require('cookie-parser');
var login 			= require('./controllers/login');
var customer		= require('./controllers/customer');
var job             = require('./controllers/job');


var app = express();

//configuration
app.set('view engine', 'ejs');


//middleware
app.use('/design', express.static('design'));
app.use(bodyParser.urlencoded({extended: false}));
app.use(exSession({secret: 'my top secret value', saveUninitialized: true, resave: false}));
app.use(cookieParser());
app.use('/login', login);
app.use('/customer', customer);
app.use('/job',job);


//routes
app.get('/', function(req, res){
	res.redirect('/login');
});

app.get('/login', function(req, res){
	res.redirect('/login');
});



//server startup
app.listen(3000, function(){
	console.log('server started at 3000!');
});